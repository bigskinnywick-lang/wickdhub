#!/usr/bin/env python3
"""Register (onboarding/features) — divergent recipe (own head + page.css + shared chrome)."""
import re, json, pathlib
U = "/mnt/user-data/uploads/wickdhub/docs/blades"
BB = pathlib.Path("/home/claude/blades-build")
name = "features"                      # output dir under onboarding/
src = pathlib.Path(f"{U}/onboarding/features/index.html").read_text(encoding="utf-8")
lines = src.split("\n")
d = BB/f"pages/{name}"; d.mkdir(parents=True, exist_ok=True)

head_part = src.split("</head>")[0]
css = "\n".join(re.findall(r"<style>(.*?)</style>", head_part, re.S))
(d/"page.css").write_text(css, encoding="utf-8")

first_style = next(i for i,l in enumerate(lines,1) if "<style>" in l)   # L10
head_top = "\n".join(lines[0:first_style-1])                            # L1..L9
head_html = (head_top +
    '\n<link rel="stylesheet" href="/blades/_shell/blades.css">' +
    '\n<link rel="stylesheet" href="/blades/onboarding/features/page.css">\n</head>')
(d/"head.html").write_text(head_html, encoding="utf-8")

def L(a,b): return "\n".join(lines[a-1:b])
(d/"content.html").write_text(L(170,272), encoding="utf-8")   # intro..footer
(d/"scripts.html").write_text(L(276,332), encoding="utf-8")

meta = {
  "docTitle": "ONYX BLADES · Systems Register v2.0",
  "h1": "SYSTEMS REGISTER · v2.0",
  "subline": "CAPABILITY MANIFEST · WHAT THE BOARD DOES · LAMP = STATUS",
  "navKey": "features",              # not a top-nav item -> none highlighted
  "secureTag": "ONYX BLADES SECURE CHANNEL · SYSTEMS REGISTER",
  "hudAside": "",
  "controlsExtra": '<button class="modebtn" id="modeBtn"></button>',
  "channel": "retail", "outDir": "onboarding/features", "ticker": False,
}
(d/"meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"register: page.css {len(css)}B, content L170-272, scripts L276-332")
