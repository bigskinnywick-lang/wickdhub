#!/usr/bin/env python3
import re, hashlib, pathlib
U = "/mnt/user-data/uploads/wickdhub/docs/blades"
BB = pathlib.Path("/home/claude/blades-build")
pages = {
  "colonization": f"{U}/colonization/index.html",
  "home":         f"{U}/index.html",
  "commander":    f"{U}/commander/index.html",
  "onboarding":   f"{U}/onboarding/index.html",
  "register":     f"{U}/onboarding/features/index.html",
}
blades_css = (BB/"styles/blades.css").read_text(encoding="utf-8")
base_md5 = hashlib.md5(blades_css.encode()).hexdigest()
print(f"blades.css (colonization shared)  {len(blades_css):>7}B  md5 {base_md5[:8]}")
print("="*78)

def head_styles(txt):
    head = txt.split("</head>")[0]
    blocks = re.findall(r"<style>(.*?)</style>", head, re.S)
    return "\n".join(blocks)

landmarks = ["<body", 'class="wrap"', 'class="secure"', 'class="hud"', "<h1", "blades-nav",
             'class="ticker"', 'class="dialbox"', 'class="controls"', "id=\"modeBtn\"",
             "SIGNAL", "<footer", "</body>", "<script"]

for name, path in pages.items():
    txt = pathlib.Path(path).read_text(encoding="utf-8")
    lines = txt.split("\n")
    hs = head_styles(txt)
    md5 = hashlib.md5(hs.encode()).hexdigest()
    same = "IDENTICAL to base" if md5 == base_md5 else "DIFFERENT"
    # count style blocks + first-script line + body-end
    firstscript = next((i for i,l in enumerate(lines,1) if "<script" in l and i>5), None)
    bodyend = next((i for i,l in enumerate(lines,1) if l.strip()=="</body>"), None)
    has_mode = 'yes' if 'id="modeBtn"' in txt else 'no'
    has_signal = 'yes' if ('ob_signal' in txt or 'data-mode' in txt) else 'no'
    print(f"\n### {name}  ({len(txt)}B, {len(lines)} lines)")
    print(f"   head-CSS: {len(hs)}B  md5 {md5[:8]}  -> {same}")
    print(f"   modeBtn: {has_mode} | SIGNAL toggle: {has_signal}")
    print(f"   first <script> line: {firstscript} | </body> line: {bodyend}")
