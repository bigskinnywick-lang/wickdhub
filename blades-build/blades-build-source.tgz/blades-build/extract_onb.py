#!/usr/bin/env python3
"""Divergent-page extractor (onboarding). Keeps the page's OWN head + its own CSS
as page.css (parity-safe: preserves data-mode default, meta, anti-flash), but adopts
the shared CHROME partial for unified nav/banner/dial. Same recipe will serve register + home."""
import re, json, pathlib
U = "/mnt/user-data/uploads/wickdhub/docs/blades"
BB = pathlib.Path("/home/claude/blades-build")
name = "onboarding"
src = pathlib.Path(f"{U}/{name}/index.html").read_text(encoding="utf-8")
lines = src.split("\n")
d = BB/f"pages/{name}"; d.mkdir(parents=True, exist_ok=True)

# page.css = the page's full head <style> content (its own palette + unique components)
head_part = src.split("</head>")[0]
css = "\n".join(re.findall(r"<style>(.*?)</style>", head_part, re.S))
(d/"page.css").write_text(css, encoding="utf-8")

# head.html = page's own head-top (L1..before first <style>) + blades.css + page.css links + </head>
first_style = next(i for i,l in enumerate(lines,1) if "<style>" in l)   # L10
head_top = "\n".join(lines[0:first_style-1])                             # L1..L9
head_html = (head_top +
    '\n<link rel="stylesheet" href="/blades/_shell/blades.css">' +
    f'\n<link rel="stylesheet" href="/blades/{name}/page.css">' +
    '\n<script src="/blades/_shell/deck.js" defer></script>' +
    '\n<script src="/blades/_shell/testpilot.js" defer></script>\n</head>')
(d/"head.html").write_text(head_html, encoding="utf-8")

# content L163-290 (intro..footer) ; scripts L294-349
def L(a,b): return "\n".join(lines[a-1:b])

TABLET_CARD = '''  <!-- BONUS: IMMERSIVE TABLET MODE -->
  <div class="step">
    <div class="step-h"><span class="num">✦</span><div><div class="t">Fly the Deck on a Tablet</div><div class="s">fullscreen kiosk mode · optional</div></div><span class="chip">optional</span></div>
    <div class="step-body">
      <div class="lore"><p>Want the board glowing edge-to-edge on a tablet by your throttle? A kiosk browser runs the deck fullscreen and keeps it that way — no browser chrome, no timeouts, your zoom locked in across every page. On a Fire tablet, sideload <b>Fully Kiosk Browser</b>; on other tablets it installs from the home screen.</p></div>
      <div class="plain">
        <ol>
          <li>Install <b>Fully Kiosk Browser</b> on the tablet (on a Fire tablet, sideload the APK — it's a standard Android app).</li>
          <li>Set its <b>Start URL</b> to <code>https://wickdhub.com/blades/colonization/</code>.</li>
          <li>Turn on <b>kiosk / fullscreen</b> in its settings — the board now runs edge-to-edge and stays fullscreen across every page.</li>
        </ol>
        <div class="kv">Signed-in members also get an on-page ⌗ fullscreen/zoom control (bottom-right) that remembers your zoom on every page.</div>
      </div>
      <a class="link" href="https://www.fully-kiosk.com/" target="_blank" rel="noopener">◉ Fully Kiosk Browser</a>
      <div class="confirm"><b>✔ Immersion check:</b> launch from the tablet's home screen and the board fills the screen — navigate anywhere and it stays fullscreen, zoom held.</div>
    </div>
  </div>

'''
content = L(163,290).replace("  <footer>", TABLET_CARD + "  <footer>", 1)
(d/"content.html").write_text(content, encoding="utf-8")
(d/"scripts.html").write_text(L(294,349), encoding="utf-8")

meta = {
  "docTitle": "ONYX BLADES · Cohort Uplink Procedures",
  "h1": "COHORT UPLINK PROCEDURES",
  "subline": "FIELD MANUAL · GET WIRED INTO THE COLONISATION BOARD",
  "navKey": "onboarding", "secureTag": "ONYX BLADES SECURE CHANNEL · UPLINK PROVISIONING", "hudAside": "",
  "controlsExtra": '<button class="modebtn" id="modeBtn"></button>',
  "channel": "retail",
}
(d/"meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"{name}: page.css {len(css)}B, own head kept, content L163-290, scripts L294-349")
