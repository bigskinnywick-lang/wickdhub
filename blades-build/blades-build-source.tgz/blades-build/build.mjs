// The baker: shell partials + page source -> docs/blades/<name>/index.html
// Usage: node build.mjs [OUTDIR]   (default: ../docs/blades ; here we pass a preview dir)
import { readFileSync, writeFileSync, mkdirSync, readdirSync, copyFileSync, existsSync } from 'fs';
import { join } from 'path';

const BB  = '/home/claude/blades-build';
const OUT = process.argv[2] || '/home/claude/serve/blades';

const NAV = [
  ['home',         'HOME',        '/blades/'],
  ['colonization', 'COLONIZATION','/blades/colonization/'],
  ['commander',    'MY STATS',    '/blades/commander/'],
  ['onboarding',   'SETUP GUIDE', '/blades/onboarding/'],
];
const navHtml = active => NAV.map(([k,label,href]) =>
  `<a class="bn${k===active?' on':''}" href="${href}">${label}</a>`).join('');

const shellHead = readFileSync(`${BB}/shell/head.html`,  'utf8');
const chrome    = readFileSync(`${BB}/shell/chrome.html`,'utf8');
const foot      = readFileSync(`${BB}/shell/foot.html`,  'utf8');

// ship the single source-of-truth stylesheet
mkdirSync(`${OUT}/_shell`, { recursive: true });
copyFileSync(`${BB}/styles/blades.css`, `${OUT}/_shell/blades.css`);
copyFileSync(`${BB}/shared/deck.js`, `${OUT}/_shell/deck.js`);
copyFileSync(`${BB}/shared/testpilot.js`, `${OUT}/_shell/testpilot.js`);

for (const name of readdirSync(`${BB}/pages`)) {
  const p = `${BB}/pages/${name}`;
  const meta = JSON.parse(readFileSync(`${p}/meta.json`, 'utf8'));

  // divergent pages carry their own head.html (own meta / data-mode / anti-flash); others use the shared shell head
  const h = existsSync(`${p}/head.html`)
    ? readFileSync(`${p}/head.html`, 'utf8')
    : shellHead.replace('{{DOCTITLE}}', meta.docTitle);

  let html;
  if (existsSync(`${p}/body.html`)) {
    // whole-body page (public storefront): head + its own body; CSS/emblem already externalized
    html = `${h}\n${readFileSync(`${p}/body.html`, 'utf8')}`;
  } else {
    const content = readFileSync(`${p}/content.html`, 'utf8');
    const scripts = existsSync(`${p}/scripts.html`) ? readFileSync(`${p}/scripts.html`, 'utf8') : '';
    const c = chrome
      .replace('{{SECURE_TAG}}',    meta.secureTag || 'ONYX BLADES SECURE CHANNEL · PRIVATE COHORT ACCESS')
      .replace('{{H1}}',            meta.h1)
      .replace('{{SUBLINE}}',       meta.subline)
      .replace('{{HUD_ASIDE}}',     meta.hudAside || '')
      .replace('{{NAV}}',           navHtml(meta.navKey))
      .replace('{{CONTROLS_EXTRA}}', meta.controlsExtra || '');
    const cc = meta.ticker === false
      ? c.replace(/\n?\s*<div class="ticker">.*?id="tickTrack"><\/div><\/div>/s, '')
      : c;
    html = `${h}\n<body>\n${cc}${content}${foot}\n${scripts}\n</body>\n</html>`;
  }

  const sub = meta.outDir ?? name;
  const base = meta.channel === 'beta' ? (sub ? `${OUT}/beta/${sub}` : `${OUT}/beta`)
                                       : (sub ? `${OUT}/${sub}` : OUT);
  mkdirSync(base, { recursive: true });
  writeFileSync(`${base}/index.html`, html);
  if (existsSync(`${p}/page.css`)) copyFileSync(`${p}/page.css`, `${base}/page.css`);
  console.log(`baked ${name.padEnd(16)} ${String(html.length).padStart(7)} bytes  ->  ${base}/index.html`);
}
