#!/usr/bin/env python3
"""One-time extractor: slice the live colonization page into shell partials +
page source. Parity-preserving — everything is copied verbatim except two
intentional swaps (inline CSS -> external blades.css link, 124KB base64 emblem
-> icon reference)."""
import re, json, pathlib

SRC = "/mnt/user-data/uploads/wickdhub/docs/blades/colonization/index.html"
BB  = pathlib.Path("/home/claude/blades-build")
lines = open(SRC, encoding="utf-8").read().split("\n")

def L(a, b):  # inclusive, 1-indexed
    return "\n".join(lines[a-1:b])

# ---- HEAD (L1-17) : replace <title>, drop inline styles, link blades.css ----
head = L(1, 17)
docTitle = re.search(r"<title>(.*?)</title>", head).group(1)
head = re.sub(r"<title>.*?</title>", "<title>{{DOCTITLE}}</title>", head, count=1)
head += '\n<link rel="stylesheet" href="/blades/_shell/blades.css">\n</head>'
(BB/"shell/head.html").write_text(head, encoding="utf-8")

# ---- CHROME (L283-316) : placeholders + emblem swap ----
chrome = L(283, 316)
h1      = re.search(r"<h1>(.*?)</h1>", chrome).group(1)
subline = re.search(r'<div class="sub" id="subline">(.*?)</div>', chrome).group(1)
liveBadge = re.search(r'<div class="mockbadge".*?</div>', chrome).group(0)
chrome = re.sub(r'src="data:image/png;base64,[^"]*"', 'src="/blades/icon-192.png"', chrome, count=1)
chrome = re.sub(r"<h1>.*?</h1>", "<h1>{{H1}}</h1>", chrome, count=1)
chrome = re.sub(r'(<div class="sub" id="subline">).*?(</div>)', r"\1{{SUBLINE}}\2", chrome, count=1)
chrome = re.sub(r'(<nav class="blades-nav">).*?(</nav>)', r"\1{{NAV}}\2", chrome, count=1)
chrome = re.sub(r'<div class="mockbadge".*?</div>', "{{LIVE_BADGE}}", chrome, count=1)
(BB/"shell/chrome.html").write_text(chrome, encoding="utf-8")

# ---- FOOT (L324-325) : wrap close + toast ----
(BB/"shell/foot.html").write_text(L(324, 325), encoding="utf-8")

# ---- PAGE CONTENT (L317-323) ----
(BB/"pages/colonization/content.html").write_text(L(317, 323), encoding="utf-8")

# ---- PAGE SCRIPTS (L327 -> line before </body>) ----
body_end = next(i for i, l in enumerate(lines, 1) if l.strip() == "</body>")
(BB/"pages/colonization/scripts.html").write_text(L(327, body_end-1), encoding="utf-8")

# ---- META ----
meta = {
    "docTitle": docTitle, "h1": h1, "subline": subline,
    "navKey": "colonization", "liveBadge": liveBadge, "channel": "retail",
}
(BB/"pages/colonization/meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

print("docTitle:", docTitle)
print("h1:", h1)
print("subline:", subline)
print("body_end line:", body_end)
for f in ["shell/head.html","shell/chrome.html","shell/foot.html",
          "pages/colonization/content.html","pages/colonization/scripts.html","pages/colonization/meta.json"]:
    print(f"{f:42} {len(open(BB/f,encoding='utf-8').read()):>8} bytes")
print("placeholders in chrome:", re.findall(r"\{\{[A-Z_]+\}\}", chrome))
