#!/usr/bin/env python3
import re, pathlib
U = "/mnt/user-data/uploads/wickdhub/docs/blades"
BB = pathlib.Path("/home/claude/blades-build")
onb = pathlib.Path(f"{U}/onboarding/index.html").read_text(encoding="utf-8")
core = (BB/"styles/blades.css").read_text(encoding="utf-8")

def head_css(txt):
    head = txt.split("</head>")[0]
    return "\n".join(re.findall(r"<style>(.*?)</style>", head, re.S))
def roots(css):
    # capture :root{...} and :root[...]{...} blocks, normalized (whitespace-insensitive)
    blocks = re.findall(r":root[^{]*\{[^}]*\}", css)
    return { re.sub(r"\s+", "", b) for b in blocks }

onb_css = head_css(onb)
r_onb, r_core = roots(onb_css), roots(core)
print(f"onboarding head-CSS: {len(onb_css)}B   blades.css: {len(core)}B")
print(f":root/theme blocks -> onboarding: {len(r_onb)}  blades.css: {len(r_core)}")
print(f"  onboarding blocks NOT in blades.css: {len(r_onb - r_core)}")
print(f"  (if 0 => onboarding's palette == shared; safe to strip its theme blocks and rely on blades.css)")
for b in list(r_onb - r_core)[:6]:
    print("   DIFF:", b[:110])
print()
# chrome landmarks
lines = onb.split("\n")
want = ['class="wrap"','class="secure"','class="hud"','<h1','class="sub','class="cmdr"','blades-nav',
        'class="ticker"','class="controls"','class="dialbox"','id="modeBtn"','SIGNAL','signalBtn',
        'class="mockbadge"','<footer','</body>']
for i,l in enumerate(lines,1):
    for w in want:
        if w in l:
            print(f"L{i:<4} {w:16} {l.strip()[:96]}")
            break
