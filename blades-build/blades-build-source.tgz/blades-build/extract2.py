#!/usr/bin/env python3
"""Generalized extractor. Rebuilds the canonical shell chrome with per-page SLOTS
(doctitle, h1, subline, hud-aside, nav, controls-extra) and slices each page's
content + scripts + meta. Reuse for every page; slots absorb the drift."""
import re, json, pathlib
U = "/mnt/user-data/uploads/wickdhub/docs/blades"
BB = pathlib.Path("/home/claude/blades-build")

def readlines(p): return pathlib.Path(p).read_text(encoding="utf-8").split("\n")
def L(lines, a, b): return "\n".join(lines[a-1:b])   # inclusive, 1-indexed

# ============ 1. CANONICAL SHELL (from colonization L283-316) ============
col = readlines(f"{U}/colonization/index.html")

# --- head.html : L1-17, swap <title>, drop inline styles, link blades.css ---
head = L(col, 1, 17)
head = re.sub(r"<title>.*?</title>", "<title>{{DOCTITLE}}</title>", head, count=1)
head += '\n<link rel="stylesheet" href="/blades/_shell/blades.css">\n<script src="/blades/_shell/deck.js" defer></script>\n</head>'
(BB/"shell/head.html").write_text(head, encoding="utf-8")

# --- chrome.html : L283-316 with line-precise slot swaps ---
chrome_lines = col[282:316]                      # L283..L316 (0-indexed slice)
def idx(n): return n - 283                        # map file line -> chrome_lines index
# capture originals (for colonization's meta)
col_secure_tag     = re.search(r'ONYX BLADES SECURE CHANNEL · [^<]+', chrome_lines[idx(285)]).group(0)
col_hud_aside      = chrome_lines[idx(298)]
col_controls_extra = chrome_lines[idx(315)]
chrome_lines[idx(285)] = re.sub(r'ONYX BLADES SECURE CHANNEL · [^<]+', '{{SECURE_TAG}}', chrome_lines[idx(285)])
# swaps
chrome_lines[idx(295)] = re.sub(r'src="data:image/png;base64,[^"]*"', 'src="/blades/icon-192.png"', chrome_lines[idx(295)])
chrome_lines[idx(296)] = re.sub(r"<h1>.*?</h1>", "<h1>{{H1}}</h1>",
                          re.sub(r'(<div class="sub"[^>]*>).*?(</div>)', r'<div class="sub" id="subline">{{SUBLINE}}</div>', chrome_lines[idx(296)]))
chrome_lines[idx(298)] = "    {{HUD_ASIDE}}"
chrome_lines[idx(300)] = re.sub(r'(<nav class="blades-nav">).*?(</nav>)', r"\1{{NAV}}\2", chrome_lines[idx(300)])
chrome_lines[idx(315)] = "    {{CONTROLS_EXTRA}}"
(BB/"shell/chrome.html").write_text("\n".join(chrome_lines), encoding="utf-8")

# --- foot.html : L324-325 (wrap close + toast) ---
(BB/"shell/foot.html").write_text(L(col, 324, 325), encoding="utf-8")

# ============ 2. PER-PAGE EXTRACTION ============
def extract(name, src, content_a, content_b, scripts_a, scripts_b, meta):
    lines = readlines(src)
    d = BB/f"pages/{name}"; d.mkdir(parents=True, exist_ok=True)
    (d/"content.html").write_text(L(lines, content_a, content_b), encoding="utf-8")
    scripts = L(lines, scripts_a, scripts_b)
    # deck controls now live in the shared /blades/_shell/deck.js — strip the old inline copy
    scripts = re.sub(r'\n?\s*<!-- deck controls: fullscreen \+ zoom.*?</script>', '', scripts, flags=re.S)
    (d/"scripts.html").write_text(scripts, encoding="utf-8")
    (d/"meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"  {name:14} content {content_a}-{content_b}  scripts {scripts_a}-{scripts_b}  meta[{','.join(meta)}]")

print("shell rebuilt with slots: DOCTITLE H1 SUBLINE HUD_ASIDE NAV CONTROLS_EXTRA")
print("pages:")
# colonization (canonical) — reuses its own captured hud-aside + controls-extra
extract("colonization", f"{U}/colonization/index.html", 317, 323, 327, 1013, {
    "docTitle": "ONYX BLADES · Live Colonisation Board", "h1": "ONYX BLADES · LIVE COLONISATION BOARD",
    "subline": "LIVE FEED · RAVENCOLONIAL + ARDENT", "navKey": "colonization", "secureTag": col_secure_tag,
    "hudAside": col_hud_aside.strip(), "controlsExtra": col_controls_extra.strip(), "channel": "retail"})
# commander (easy twin) — no hud-aside, no controls-extra
extract("commander", f"{U}/commander/index.html", 308, 333, 336, 804, {
    "docTitle": "ONYX BLADES · COMMANDER DOSSIER", "h1": "COMMANDER DOSSIER",
    "subline": "PERSONAL DELIVERY STATS", "navKey": "commander", "secureTag": "ONYX BLADES SECURE CHANNEL · PRIVATE COHORT ACCESS",
    "hudAside": "", "controlsExtra": "", "channel": "retail"})
