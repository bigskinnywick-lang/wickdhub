#!/usr/bin/env python3
"""Home (public storefront) — whole-body recipe: keep the entire storefront body intact,
only (1) externalize inline CSS -> blades.css + page.css, (2) swap the 124KB crest -> icon-192.
Decorative ring/seal images stay inline. Storefront behaviour (secure bar, whoami, presence,
loop launcher, locked-nav JS) untouched."""
import re, json, pathlib
U = "/mnt/user-data/uploads/wickdhub/docs/blades"
BB = pathlib.Path("/home/claude/blades-build")
src = pathlib.Path(f"{U}/index.html").read_text(encoding="utf-8")
lines = src.split("\n")
d = BB/"pages/home"; d.mkdir(parents=True, exist_ok=True)

# page.css = the single head <style> block
head_part = src.split("</head>")[0]
css = "\n".join(re.findall(r"<style>(.*?)</style>", head_part, re.S))
(d/"page.css").write_text(css, encoding="utf-8")

# head.html = L1..before first <style> + shared + page css links + </head>
first_style = next(i for i,l in enumerate(lines,1) if "<style>" in l)   # L11
head_top = "\n".join(lines[0:first_style-1])                            # L1..L10
(d/"head.html").write_text(
    head_top +
    '\n<link rel="stylesheet" href="/blades/_shell/blades.css">' +
    '\n<link rel="stylesheet" href="/blades/page.css">' +
    '\n<script src="/blades/_shell/deck.js" defer></script>\n</head>', encoding="utf-8")

# body.html = <body>..</html> (L233..end), swap ONLY the .emblem crest -> icon
body = "\n".join(lines[232:])                                           # L233..end
new_body, n = re.subn(r'(<img class="emblem"[^>]*src=")data:image/png;base64,[^"]*(")',
                      r'\1/blades/icon-192.png\2', body, count=1)
assert n == 1, f"expected 1 emblem swap, did {n}"
(d/"body.html").write_text(new_body, encoding="utf-8")

meta = {"docTitle": "ONYX BLADES · Squadron Command", "channel": "retail", "outDir": ""}
(d/"meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"home: page.css {len(css)}B, body {len(new_body)}B, emblem swaps {n} (ring/seal left inline)")
