"""
Onyx Blades — Build Registrar (EDMC plugin)

When you dock at a colonisation construction ship, Elite writes a
ColonisationConstructionDepot journal event (MarketID). This plugin pairs that
with the current SystemAddress and posts them to the Onyx Blades board's ingest
endpoint, which resolves the RavenColonial buildId and adds it to the squad's
build list automatically.

AUTO-CREATE (optional, off by default): if no build exists in RavenColonial for
the construction site after a short grace period (giving the architect / SrvSurvey
a chance to create it first), the board can create one for you and register it.
Because RavenColonial is a shared community service, this is safeguarded:
  * off unless you enable it in EDMC settings,
  * only fires after the grace period with the site still unregistered,
  * the architect is auto-detected from other builds in the same system when
    possible, otherwise your squad name is used (edit it in Raven later).

Install: drop this "BladesRegistrar" folder into your EDMC plugins folder
  Windows:  %LOCALAPPDATA%\\EDMarketConnector\\plugins
  macOS:    ~/Library/Application Support/EDMarketConnector/plugins
  Linux:    ~/.local/share/EDMarketConnector/plugins
then fully restart EDMC. Runs alongside the RavenColonial plugin.
"""
import json
import os
import threading
import time
import urllib.request
import urllib.error

PLUGIN_NAME = "Blades Registrar"

# --- config -----------------------------------------------------------------
INGEST_URL = "https://wickdhub.com/ingest/build"
INGEST_KEY = "6bb6a945625356d9054ea5ec25e65828b1e6061f"

# Defaults; overridable in EDMC settings (File > Settings > Blades Registrar).
DEFAULT_AUTOCREATE = False
DEFAULT_ARCHITECT = "Onyx Blades"
DEFAULT_GRACE_MIN = 5
# ----------------------------------------------------------------------------

BROWSER_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
              "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36")

# EDMC config (optional — guarded so the plugin still loads without it).
try:
    from config import config as _cfg
except Exception:
    _cfg = None

_state = {
    "dir": "", "sa": None, "system": None, "body": None, "bodynum": None,
    "seen": set(), "pending": {}, "status": None,
}


def _cfg_bool(key, default):
    if _cfg is None:
        return default
    try:
        return bool(_cfg.get_bool(key, default=default))
    except Exception:
        try:
            v = _cfg.getint(key)
            return default if v is None else bool(v)
        except Exception:
            return default


def _cfg_str(key, default):
    if _cfg is None:
        return default
    try:
        v = _cfg.get_str(key, default=default)
    except Exception:
        try:
            v = _cfg.get(key)
        except Exception:
            v = None
    return v if v else default


def _cfg_int(key, default):
    if _cfg is None:
        return default
    try:
        v = _cfg.get_int(key, default=default)
    except Exception:
        try:
            v = _cfg.getint(key)
        except Exception:
            v = None
    return default if v is None else int(v)


def _autocreate():
    return _cfg_bool("blades_autocreate", DEFAULT_AUTOCREATE)


def _architect():
    return _cfg_str("blades_architect", DEFAULT_ARCHITECT)


def _grace_seconds():
    return max(0, _cfg_int("blades_grace_min", DEFAULT_GRACE_MIN)) * 60


# --- seen persistence -------------------------------------------------------
def _seen_path():
    return os.path.join(_state["dir"], "registered.json")


def _load_seen():
    try:
        with open(_seen_path(), "r", encoding="utf-8") as f:
            _state["seen"] = set(json.load(f))
    except Exception:
        _state["seen"] = set()


def _save_seen():
    try:
        with open(_seen_path(), "w", encoding="utf-8") as f:
            json.dump(sorted(_state["seen"]), f)
    except Exception:
        pass


def _set_status(text):
    lbl = _state.get("status")
    if lbl is not None:
        try:
            lbl["text"] = "Blades: " + text
        except Exception:
            pass


# --- EDMC lifecycle ---------------------------------------------------------
def plugin_start3(plugin_dir):
    _state["dir"] = plugin_dir
    _load_seen()
    return PLUGIN_NAME


def plugin_app(parent):
    try:
        import tkinter as tk
        lbl = tk.Label(parent, text="Blades: idle")
        _state["status"] = lbl
        return lbl
    except Exception:
        return None


# Settings tab: enable auto-create, set the fallback architect, and the grace period.
def plugin_prefs(parent, cmdr, is_beta):
    try:
        import tkinter as tk
        try:
            import myNotebook as nb
        except Exception:
            nb = None
        F = nb.Frame if nb else tk.Frame
        L = nb.Label if nb else tk.Label
        C = nb.Checkbutton if nb else tk.Checkbutton
        E = nb.Entry if nb else tk.Entry

        frame = F(parent)
        _prefs["autocreate"] = tk.IntVar(value=1 if _autocreate() else 0)
        _prefs["architect"] = tk.StringVar(value=_architect())
        _prefs["grace"] = tk.StringVar(value=str(_grace_seconds() // 60))

        r = 0
        L(frame, text="Onyx Blades — Build Registrar").grid(row=r, column=0, columnspan=2, sticky="w", padx=8, pady=(8, 2)); r += 1
        C(frame, text="Auto-create a build in Raven when none exists (safeguarded)",
          variable=_prefs["autocreate"]).grid(row=r, column=0, columnspan=2, sticky="w", padx=8); r += 1
        L(frame, text="Fallback architect (used when it can't be auto-detected):").grid(row=r, column=0, sticky="w", padx=8, pady=(6, 0)); r += 1
        E(frame, textvariable=_prefs["architect"], width=24).grid(row=r, column=0, sticky="w", padx=8); r += 1
        L(frame, text="Grace period before auto-create (minutes):").grid(row=r, column=0, sticky="w", padx=8, pady=(6, 0)); r += 1
        E(frame, textvariable=_prefs["grace"], width=6).grid(row=r, column=0, sticky="w", padx=8, pady=(0, 8)); r += 1
        return frame
    except Exception:
        return None


def prefs_changed(cmdr, is_beta):
    if _cfg is None:
        return
    try:
        if "autocreate" in _prefs:
            _cfg.set("blades_autocreate", 1 if _prefs["autocreate"].get() else 0)
        if "architect" in _prefs:
            _cfg.set("blades_architect", (_prefs["architect"].get() or DEFAULT_ARCHITECT).strip())
        if "grace" in _prefs:
            try:
                g = int(_prefs["grace"].get())
            except Exception:
                g = DEFAULT_GRACE_MIN
            _cfg.set("blades_grace_min", max(0, g))
    except Exception:
        pass


_prefs = {}


# --- ingest -----------------------------------------------------------------
def _post(payload, market_id, was_create):
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        INGEST_URL, data=data,
        headers={
            "Content-Type": "application/json",
            # A normal browser UA — Cloudflare's Browser Integrity Check blocks
            # the default "Python-urllib/..." UA with a 403.
            "User-Agent": BROWSER_UA,
            "Accept": "application/json",
        }, method="POST",
    )
    try:
        try:
            with urllib.request.urlopen(req, timeout=20) as resp:
                body = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as he:
            detail = {}
            try:
                detail = json.loads(he.read().decode("utf-8"))
            except Exception:
                pass
            if he.code == 404:
                # No build for this market yet — keep waiting (don't mark seen).
                _report_waiting(market_id)
            elif he.code == 401:
                _set_status("auth error (bad key)")
            elif he.code == 502 and detail.get("error") == "create_failed":
                reason = detail.get("reason", "?")
                if reason == "raven_auth":
                    _set_status("auto-create needs Raven login — create it in SrvSurvey")
                else:
                    _set_status("auto-create failed (" + str(reason) + ") — will retry")
                # back off: re-arm the grace timer so we don't hammer Raven.
                _state["pending"][market_id] = time.time()
            else:
                _set_status("ingest error " + str(he.code))
            return
        if body.get("ok"):
            _state["seen"].add(market_id)
            _state["pending"].pop(market_id, None)
            _save_seen()
            if body.get("created"):
                who = body.get("architect") or "?"
                _set_status("created " + (body.get("name") or body.get("id", "build")) + " · architect " + who)
            elif body.get("added"):
                _set_status("registered " + (body.get("name") or body.get("id", "build")))
            else:
                _set_status("already listed")
        else:
            _set_status("skip (" + str(body.get("error", "?")) + ")")
    except Exception:
        _set_status("post failed (offline?)")


def _report_waiting(market_id):
    if _autocreate():
        first = _state["pending"].get(market_id)
        if first is None:
            _set_status("waiting — no build in Raven yet")
            return
        remaining = int(_grace_seconds() - (time.time() - first))
        if remaining > 0:
            m, s = divmod(remaining, 60)
            _set_status("waiting — auto-create in %dm%02ds" % (m, s))
        else:
            _set_status("waiting — arming auto-create…")
    else:
        _set_status("waiting — create the build in Raven first")


def journal_entry(cmdr, is_beta, system, station, entry, state):
    ev = entry.get("event")

    # Track location context from any event that carries it.
    if entry.get("SystemAddress"):
        _state["sa"] = entry["SystemAddress"]
    elif state and state.get("SystemAddress"):
        _state["sa"] = state.get("SystemAddress")
    if system:
        _state["system"] = system
    if entry.get("BodyName"):
        _state["body"] = entry.get("BodyName")
    elif entry.get("Body") and isinstance(entry.get("Body"), str):
        _state["body"] = entry.get("Body")
    if entry.get("BodyID") is not None:
        _state["bodynum"] = entry.get("BodyID")

    if ev != "ColonisationConstructionDepot":
        return

    market_id = entry.get("MarketID")
    sa = _state["sa"] or (state.get("SystemAddress") if state else None)
    if not market_id or not sa:
        return
    if market_id in _state["seen"]:
        return  # already registered this depot

    now = time.time()
    _state["pending"].setdefault(market_id, now)

    do_create = False
    if _autocreate() and (now - _state["pending"][market_id]) >= _grace_seconds():
        do_create = True

    payload = {
        "key": INGEST_KEY,
        "marketId": market_id,
        "systemAddress": sa,
        "cmdr": cmdr or "unknown",
        "create": do_create,
        "architect": _architect(),
        "systemName": _state.get("system") or system or "",
        "bodyName": _state.get("body") or "",
        "bodyNum": _state.get("bodynum"),
    }
    threading.Thread(target=_post, args=(payload, market_id, do_create), daemon=True).start()
