"""
Onyx Blades — Build Registrar (EDMC plugin)

When you dock at a colonisation construction ship, Elite writes a
ColonisationConstructionDepot journal event (MarketID). This plugin pairs that
with the current SystemAddress and posts them to the Onyx Blades board's ingest
endpoint, which resolves the RavenColonial buildId and adds it to the squad's
build list automatically.

AUTO-CREATE (optional, off by default): if no build exists in RavenColonial for
the construction site after a short grace period (giving the architect / SrvSurvey
a chance to create it first), the board can create one for you and register it.
Because RavenColonial is a shared community service, this is safeguarded:
  * off unless you enable it in EDMC settings,
  * only fires after the grace period with the site still unregistered,
  * the architect is auto-detected: first from your own claims, then from
    active Raven siblings in the same system, then from completed siblings
    on the board — otherwise your squad name is used (edit it in Raven later).

CLAIMS LEDGER (architect attribution, added 2026-07-21): the game never tells a
visitor who a system's architect is — but ColonisationSystemClaim only ever
appears in the ARCHITECT's own journal (it fires when YOU pay for the claim).
So this plugin reports claims to the squad's claims ledger:
  * live — whenever a claim (or claim release) event fires while EDMC runs,
  * backfill — a one-time scan of your local journal history on first launch,
    reporting every system you ever claimed on this PC (marker file
    claims_backfill.json in the plugin folder; delete it to re-run the scan).
The board's ingest endpoint then attributes builds claims-first, so auto-created
Raven builds carry the real architect instead of the squad fallback.

Install: drop this "BladesRegistrar" folder into your EDMC plugins folder
  Windows:  %LOCALAPPDATA%\\EDMarketConnector\\plugins
  macOS:    ~/Library/Application Support/EDMarketConnector/plugins
  Linux:    ~/.local/share/EDMarketConnector/plugins
then fully restart EDMC. Runs alongside the RavenColonial plugin.
"""
import calendar
import json
import os
import threading
import time
import urllib.request
import urllib.error

PLUGIN_NAME = "Blades Registrar"
PLUGIN_VERSION = "1.6"  # 1.6: ship + cargo reporting (Loadout/Cargo -> /ingest/loadout)

# --- config -----------------------------------------------------------------
INGEST_URL = "https://wickdhub.com/ingest/build"
CLAIM_URL = "https://wickdhub.com/ingest/claim"
CARRIER_URL = "https://wickdhub.com/ingest/carrier"
LOADOUT_URL = "https://wickdhub.com/ingest/loadout"
INGEST_KEY = "6bb6a945625356d9054ea5ec25e65828b1e6061f"
RAVEN_BASE = "https://ravencolonial100-awcbdvabgze4c5cq.canadacentral-01.azurewebsites.net"

# Defaults; overridable in EDMC settings (File > Settings > Blades Registrar).
DEFAULT_AUTOCREATE = False
DEFAULT_ARCHITECT = "Onyx Blades"
DEFAULT_GRACE_MIN = 5
# ----------------------------------------------------------------------------

BROWSER_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
              "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36")

# EDMC config (optional — guarded so the plugin still loads without it).
try:
    from config import config as _cfg
except Exception:
    _cfg = None

_state = {
    "dir": "", "sa": None, "system": None, "body": None, "bodynum": None,
    "seen": set(), "pending": {}, "status": None, "commodities": {},
    "claims": {},  # {systemAddress: cmdr} — local architect cache from claims
}


def _cfg_bool(key, default):
    if _cfg is None:
        return default
    try:
        return bool(_cfg.get_bool(key, default=default))
    except Exception:
        try:
            v = _cfg.getint(key)
            return default if v is None else bool(v)
        except Exception:
            return default


def _cfg_str(key, default):
    if _cfg is None:
        return default
    try:
        v = _cfg.get_str(key, default=default)
    except Exception:
        try:
            v = _cfg.get(key)
        except Exception:
            v = None
    return v if v else default


def _cfg_int(key, default):
    if _cfg is None:
        return default
    try:
        v = _cfg.get_int(key, default=default)
    except Exception:
        try:
            v = _cfg.getint(key)
        except Exception:
            v = None
    return default if v is None else int(v)


def _autocreate():
    return _cfg_bool("blades_autocreate", DEFAULT_AUTOCREATE)


def _architect():
    return _cfg_str("blades_architect", DEFAULT_ARCHITECT)


def _grace_seconds():
    return max(0, _cfg_int("blades_grace_min", DEFAULT_GRACE_MIN)) * 60


# --- seen persistence -------------------------------------------------------
def _seen_path():
    return os.path.join(_state["dir"], "registered.json")


def _load_seen():
    try:
        with open(_seen_path(), "r", encoding="utf-8") as f:
            _state["seen"] = set(json.load(f))
    except Exception:
        _state["seen"] = set()


def _save_seen():
    try:
        with open(_seen_path(), "w", encoding="utf-8") as f:
            json.dump(sorted(_state["seen"]), f)
    except Exception:
        pass


def _set_status(text):
    lbl = _state.get("status")
    if lbl is not None:
        try:
            lbl["text"] = "Blades: " + text
        except Exception:
            pass


# --- claims ledger ----------------------------------------------------------
BACKFILL_MARKER = "claims_backfill.json"


def _iso_ms(ts):
    """Journal ISO timestamp ('2026-07-21T03:00:00Z') -> epoch millis."""
    try:
        return calendar.timegm(time.strptime(ts, "%Y-%m-%dT%H:%M:%SZ")) * 1000
    except Exception:
        return int(time.time() * 1000)


def _http_json(url, payload, timeout=20):
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url, data=data,
        headers={
            "Content-Type": "application/json",
            "User-Agent": BROWSER_UA,  # Cloudflare BIC rejects Python-urllib UAs
            "Accept": "application/json",
        }, method="POST",
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _send_claim(payload, label):
    try:
        body = _http_json(CLAIM_URL, payload)
        if body.get("ok"):
            _set_status(label)
        else:
            _set_status("claim error (" + str(body.get("error", "?")) + ")")
    except urllib.error.HTTPError as he:
        _set_status("claim auth error (bad key)" if he.code == 401 else "claim error " + str(he.code))
    except Exception:
        _set_status("claim post failed (offline?)")


def _send_carrier(payload, label):
    try:
        body = _http_json(CARRIER_URL, payload)
        if body.get("ok"):
            _set_status(label)
        else:
            _set_status("carrier error (" + str(body.get("error", "?")) + ")")
    except urllib.error.HTTPError as he:
        _set_status("carrier auth error (bad key)" if he.code == 401 else "carrier error " + str(he.code))
    except Exception:
        _set_status("carrier post failed (offline?)")


# --- ship + cargo hold (loadout) --------------------------------------------
# Reported from the game's Loadout (ship + max cargo) and Cargo (current tonnage)
# events so the boards can show, per member, what everyone flies and can haul.
_LO = {"ship": "", "shipName": "", "cargoCap": None, "cargoUsed": None, "last_post": 0.0, "sig": None}


def _send_loadout(payload, label):
    try:
        body = _http_json(LOADOUT_URL, payload)
        if body.get("ok"):
            _set_status(label)
        else:
            _set_status("loadout error (" + str(body.get("error", "?")) + ")")
    except urllib.error.HTTPError as he:
        _set_status("loadout auth error (bad key)" if he.code == 401 else "loadout error " + str(he.code))
    except Exception:
        _set_status("loadout post failed (offline?)")


def _maybe_send_loadout(cmdr, ts, force=False):
    # Need a ship + a known capacity before it's worth reporting.
    if _LO["cargoCap"] is None or not _LO["ship"]:
        return
    sig = (_LO["ship"], _LO["shipName"], _LO["cargoCap"], _LO["cargoUsed"])
    now = time.time()
    # Debounce Cargo spam: post only on a real change, at most every 6s
    # (a ship swap / new Loadout forces through immediately).
    if not force:
        if sig == _LO["sig"]:
            return
        if (now - _LO["last_post"]) < 6.0:
            return
    _LO["sig"] = sig
    _LO["last_post"] = now
    payload = {
        "key": INGEST_KEY,
        "cmdr": cmdr or "unknown",
        "ship": _LO["ship"],
        "shipName": _LO["shipName"],
        "cargoCap": _LO["cargoCap"],
        "cargoUsed": _LO["cargoUsed"] or 0,
        "ts": ts,
        "via": "live",
    }
    label = "hold logged: " + (_LO["shipName"] or _LO["ship"]) + " " + str(_LO["cargoUsed"] or 0) + "/" + str(_LO["cargoCap"]) + "t"
    threading.Thread(target=_send_loadout, args=(payload, label), daemon=True).start()


def _journal_dir():
    """The game's journal folder: EDMC's setting first, then platform defaults."""
    if _cfg is not None:
        try:
            d = _cfg.get_str("journaldir")
            if d and os.path.isdir(d):
                return d
        except Exception:
            pass
    home = os.path.expanduser("~")
    for d in (
        os.path.join(os.environ.get("USERPROFILE", home), "Saved Games", "Frontier Developments", "Elite Dangerous"),
        os.path.join(home, "Library", "Application Support", "Frontier Developments", "Elite Dangerous"),
        os.path.join(home, ".local", "share", "Frontier Developments", "Elite Dangerous"),
    ):
        if os.path.isdir(d):
            return d
    return None


def _scan_journals(jdir):
    """One pass over journal history (chronological by filename). Returns the
    systems whose FINAL state is 'claimed', each paired with the commander who
    was logged in when the claim fired — that commander IS the architect."""
    claims = {}
    try:
        files = sorted(f for f in os.listdir(jdir) if f.startswith("Journal") and f.endswith(".log"))
    except Exception:
        return []
    for fn in files:
        try:
            with open(os.path.join(jdir, fn), "r", encoding="utf-8", errors="ignore") as f:
                text = f.read()
        except Exception:
            continue
        if "ColonisationSystemClaim" not in text:
            continue
        file_cmdr = None
        for line in text.splitlines():
            # cheap pre-filter: only json-parse lines that can matter
            if '"Commander"' not in line and "ColonisationSystemClaim" not in line:
                continue
            try:
                e = json.loads(line)
            except Exception:
                continue
            ev = e.get("event")
            if ev == "Commander":
                file_cmdr = e.get("Name") or file_cmdr
            elif ev == "LoadGame":
                file_cmdr = e.get("Commander") or file_cmdr
            elif ev == "ColonisationSystemClaim":
                sa = e.get("SystemAddress")
                if sa and file_cmdr:
                    claims[sa] = {
                        "systemAddress": sa,
                        "systemName": e.get("StarSystem") or "",
                        "cmdr": file_cmdr,
                        "ts": _iso_ms(e.get("timestamp")),
                        "action": "claim",
                    }
            elif ev == "ColonisationSystemClaimRelease":
                claims.pop(e.get("SystemAddress"), None)
    return list(claims.values())


def _scan_carriers(jdir):
    """One pass over journal history for fleet-carrier ownership. CarrierStats only
    appears in the OWNER's own journal, so the last one per carrier names its owner.
    Returns [{marketId, callsign, name, cmdr, ts}] (newest per market)."""
    carriers = {}
    try:
        files = sorted(f for f in os.listdir(jdir) if f.startswith("Journal") and f.endswith(".log"))
    except Exception:
        return []
    for fn in files:
        try:
            with open(os.path.join(jdir, fn), "r", encoding="utf-8", errors="ignore") as f:
                text = f.read()
        except Exception:
            continue
        if "CarrierStats" not in text:
            continue
        file_cmdr = None
        for line in text.splitlines():
            if '"Commander"' not in line and "CarrierStats" not in line and "LoadGame" not in line:
                continue
            try:
                e = json.loads(line)
            except Exception:
                continue
            ev = e.get("event")
            if ev == "Commander":
                file_cmdr = e.get("Name") or file_cmdr
            elif ev == "LoadGame":
                file_cmdr = e.get("Commander") or file_cmdr
            elif ev == "CarrierStats":
                mid = e.get("CarrierID")
                if mid and file_cmdr:
                    carriers[mid] = {
                        "marketId": mid,
                        "callsign": e.get("Callsign") or "",
                        "name": e.get("Name") or "",
                        "cmdr": file_cmdr,
                        "ts": _iso_ms(e.get("timestamp")),
                    }
    return list(carriers.values())


def _backfill_path():
    return os.path.join(_state["dir"], BACKFILL_MARKER)


def _write_backfill_marker(n):
    try:
        with open(_backfill_path(), "w", encoding="utf-8") as f:
            json.dump({"done": True, "count": n, "ts": int(time.time())}, f)
    except Exception:
        pass


def _run_backfill(delay=10):
    """Journal-history claim scan -> report your final-'claimed' systems to the
    ledger. Runs at launch only when auto-create is on, and again immediately
    (delay=0) when you save the settings tab with auto-create on. One-time per
    marker; saving the tab clears the marker so it re-scans."""
    try:
        if delay:
            time.sleep(delay)  # let EDMC finish booting (status label, journal catch-up)
        if os.path.exists(_backfill_path()):
            return
        jdir = _journal_dir()
        if not jdir:
            _set_status("claims backfill: journal folder not found")
            return
        # Fleet-carrier ownership backfill (independent of claims -- a pilot may own a
        # carrier but have no claims). Best-effort; failure never blocks the claims scan.
        try:
            cfound = _scan_carriers(jdir)
            for i in range(0, len(cfound), 100):
                _http_json(CARRIER_URL, {"key": INGEST_KEY, "via": "backfill",
                                         "carriers": cfound[i:i + 100]}, timeout=30)
        except Exception:
            pass
        found = _scan_journals(jdir)
        # Cache claims locally for architect detection during auto-create.
        for c in found:
            sa = c.get("systemAddress")
            cmdr_name = c.get("cmdr")
            if sa and cmdr_name:
                _state["claims"][sa] = cmdr_name
        if not found:
            _write_backfill_marker(0)
            return
        sent = 0
        try:
            for i in range(0, len(found), 100):
                body = _http_json(CLAIM_URL, {"key": INGEST_KEY, "via": "backfill",
                                              "claims": found[i:i + 100]}, timeout=30)
                if not body.get("ok"):
                    _set_status("claims backfill error (" + str(body.get("error", "?")) + ")")
                    return
                sent += len(found[i:i + 100])
        except urllib.error.HTTPError as he:
            _set_status("claims backfill auth error (bad key)" if he.code == 401
                        else "claims backfill error " + str(he.code))
            return
        except Exception:
            _set_status("claims backfill failed (offline?) — will retry next launch")
            return
        _write_backfill_marker(sent)
        _set_status("claims backfill: %d system(s) reported" % sent)
    except Exception:
        pass


# --- EDMC lifecycle ---------------------------------------------------------
def plugin_start3(plugin_dir):
    _state["dir"] = plugin_dir
    _load_seen()
    # Only scan/report past claims if the pilot has opted into auto-create.
    if _autocreate():
        threading.Thread(target=_run_backfill, daemon=True).start()
    return PLUGIN_NAME


def plugin_app(parent):
    try:
        import tkinter as tk
        lbl = tk.Label(parent, text="Blades: idle (v" + PLUGIN_VERSION + ")")
        _state["status"] = lbl
        return lbl
    except Exception:
        return None


# Settings tab: enable auto-create, set the fallback architect, and the grace period.
def plugin_prefs(parent, cmdr, is_beta):
    try:
        import tkinter as tk
        try:
            import myNotebook as nb
        except Exception:
            nb = None
        # Resolve widgets defensively: recent EDMC (myNotebook.py) renamed
        # Entry -> EntryMenu and may rename others, so fall back gracefully
        # instead of letting an AttributeError kill the whole settings tab.
        F = getattr(nb, "Frame", tk.Frame) if nb else tk.Frame
        L = getattr(nb, "Label", tk.Label) if nb else tk.Label
        C = getattr(nb, "Checkbutton", tk.Checkbutton) if nb else tk.Checkbutton
        E = (getattr(nb, "Entry", None) or getattr(nb, "EntryMenu", tk.Entry)) if nb else tk.Entry

        frame = F(parent)
        _prefs["autocreate"] = tk.IntVar(value=1 if _autocreate() else 0)
        _prefs["architect"] = tk.StringVar(value=_architect())
        _prefs["grace"] = tk.StringVar(value=str(_grace_seconds() // 60))

        r = 0
        L(frame, text="Onyx Blades — Build Registrar").grid(row=r, column=0, columnspan=2, sticky="w", padx=8, pady=(8, 2)); r += 1
        C(frame, text="Auto-create a build in Raven when none exists (safeguarded)",
          variable=_prefs["autocreate"]).grid(row=r, column=0, columnspan=2, sticky="w", padx=8); r += 1
        L(frame, text="Fallback architect (used when it can't be auto-detected):").grid(row=r, column=0, sticky="w", padx=8, pady=(6, 0)); r += 1
        E(frame, textvariable=_prefs["architect"], width=24).grid(row=r, column=0, sticky="w", padx=8); r += 1
        L(frame, text="Grace period before auto-create (minutes):").grid(row=r, column=0, sticky="w", padx=8, pady=(6, 0)); r += 1
        E(frame, textvariable=_prefs["grace"], width=6).grid(row=r, column=0, sticky="w", padx=8, pady=(0, 8)); r += 1
        return frame
    except Exception:
        return None


def prefs_changed(cmdr, is_beta):
    if _cfg is None:
        return
    try:
        if "autocreate" in _prefs:
            _cfg.set("blades_autocreate", 1 if _prefs["autocreate"].get() else 0)
        if "architect" in _prefs:
            _cfg.set("blades_architect", (_prefs["architect"].get() or DEFAULT_ARCHITECT).strip())
        if "grace" in _prefs:
            try:
                g = int(_prefs["grace"].get())
            except Exception:
                g = DEFAULT_GRACE_MIN
            _cfg.set("blades_grace_min", max(0, g))
        # Saving the tab with auto-create ON = "report my claims now": clear the
        # one-time marker and re-scan immediately, no EDMC restart needed.
        if _prefs.get("autocreate") and _prefs["autocreate"].get():
            try:
                os.remove(_backfill_path())
            except OSError:
                pass
            threading.Thread(target=lambda: _run_backfill(0), daemon=True).start()
    except Exception:
        pass


_prefs = {}


# --- system architect lookup ------------------------------------------------

def _raven_system_architect(system_address):
    """Query Raven for ACTIVE builds in this system; return the architectName
    from the first sibling that has a real (non-fallback) architect, or None."""
    try:
        fallback = _architect()
        url = RAVEN_BASE + "/api/system/" + str(system_address)
        req = urllib.request.Request(url, headers={
            "User-Agent": BROWSER_UA, "Accept": "application/json",
        })
        with urllib.request.urlopen(req, timeout=30) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
        builds = json.loads(raw)
        if isinstance(builds, list):
            for b in builds:
                arch = b.get("architectName") or ""
                if arch and arch != fallback:
                    return arch
    except Exception:
        pass
    return None


def _board_system_architect(system_name):
    """Ask the board for the architect of a system by checking sibling builds
    in KV (covers completed builds that Raven no longer exposes). Requires the
    /ingest/architect endpoint — gracefully returns None if it doesn't exist yet."""
    if not system_name:
        return None
    try:
        url = INGEST_URL.rsplit("/", 1)[0] + "/architect?system=" + urllib.request.quote(system_name)
        req = urllib.request.Request(url, headers={
            "User-Agent": BROWSER_UA, "Accept": "application/json",
        })
        with urllib.request.urlopen(req, timeout=10) as resp:
            body = json.loads(resp.read().decode("utf-8", errors="replace"))
        return body.get("architect") or None
    except Exception:
        return None


# --- direct Raven create (bypasses Cloudflare function timeout) -------------

def _raven_create(market_id, system_address, build_name, architect_name, system_name="", body_name="", body_num=None, commodities=None):
    """PUT directly to RavenColonial to create a build. Retries up to 3 times
    with backoff to handle Azure cold starts. Returns the parsed JSON response
    on success, or None on failure (status line + last_error.json updated)."""
    raven_url = RAVEN_BASE + "/api/project"
    payload = {
        "marketId": market_id,
        "systemAddress": system_address,
        "buildName": build_name,
        "architectName": architect_name,
        "systemName": system_name,
        "buildType": "consus",  # Raven's type for colonisation construction sites
    }
    if commodities:
        payload["commodities"] = commodities
    if body_name:
        payload["bodyName"] = body_name
    if body_num is not None:
        payload["bodyNum"] = body_num

    data = json.dumps(payload).encode("utf-8")
    last_err = None
    for attempt in range(3):
        if attempt > 0:
            wait = 10 * attempt  # 10s, 20s backoff
            _set_status("Raven cold — retry %d in %ds…" % (attempt + 1, wait))
            time.sleep(wait)
        try:
            req = urllib.request.Request(
                raven_url, data=data,
                headers={
                    "Content-Type": "application/json",
                    "User-Agent": BROWSER_UA,
                    "Accept": "application/json",
                }, method="PUT",
            )
            with urllib.request.urlopen(req, timeout=60) as resp:
                raw = resp.read().decode("utf-8", errors="replace")
            return json.loads(raw)
        except urllib.error.HTTPError as he:
            raw = ""
            try:
                raw = he.read().decode("utf-8", errors="replace")
            except Exception:
                pass
            last_err = ("raven_http_%d" % he.code, raw)
        except Exception as e:
            last_err = ("raven_exception", str(e))
    # All retries exhausted
    if last_err:
        _write_last_error(0, last_err[1], {"raven_direct": True, "marketId": market_id,
                                            "systemAddress": system_address, "reason": last_err[0]})
        _set_status("Raven create failed (%s) — logged" % last_err[0])
    return None


# --- ingest -----------------------------------------------------------------
LAST_ERROR_FILE = "last_error.json"


def _write_last_error(status, raw, payload):
    """Persist the full failure (status + raw body + request summary) so a blind
    502 always leaves a readable trail in the plugin folder. This is the thing
    that turns 'ingest error 502' from a dead end into a diagnosable cause."""
    try:
        summary = {k: payload.get(k) for k in
                   ("marketId", "systemAddress", "cmdr", "create", "systemName")}
        with open(os.path.join(_state["dir"], LAST_ERROR_FILE), "w", encoding="utf-8") as f:
            json.dump({"ts": int(time.time()), "http_status": status,
                       "raw_body": (raw or "")[:2000], "request": summary}, f, indent=1)
    except Exception:
        pass


def _post(payload, market_id, was_create):
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        INGEST_URL, data=data,
        headers={
            "Content-Type": "application/json",
            # A normal browser UA — Cloudflare's Browser Integrity Check blocks
            # the default "Python-urllib/..." UA with a 403.
            "User-Agent": BROWSER_UA,
            "Accept": "application/json",
        }, method="POST",
    )
    try:
        # Timeout sits ABOVE the server's overall deadline (22s) so we actually
        # receive its structured 502 instead of giving up first and blaming "offline".
        try:
            with urllib.request.urlopen(req, timeout=25) as resp:
                raw = resp.read().decode("utf-8", errors="replace")
            body = json.loads(raw)
        except urllib.error.HTTPError as he:
            # Read the raw error body (JSON or not) — never discard it.
            raw = ""
            try:
                raw = he.read().decode("utf-8", errors="replace")
            except Exception:
                pass
            detail = {}
            try:
                detail = json.loads(raw)
            except Exception:
                pass
            if he.code == 404:
                if was_create:
                    # Grace expired, no build in Raven — create directly (bypasses CF timeout).
                    _set_status("creating in Raven (direct)…")
                    sys_name = payload.get("systemName") or ""
                    build_name = (sys_name + " Construction Site") if sys_name else "Construction Site"
                    # Architect: claims-first, then Raven siblings, then board siblings, then fallback.
                    sa = payload.get("systemAddress")
                    sys_name_for_lookup = sys_name
                    architect = _state["claims"].get(sa)
                    if not architect:
                        _set_status("checking Raven for system architect…")
                        architect = _raven_system_architect(sa)
                    if not architect:
                        _set_status("checking board for system architect…")
                        architect = _board_system_architect(sys_name_for_lookup)
                    if not architect:
                        architect = _architect()
                    result = _raven_create(
                        payload["marketId"], payload["systemAddress"], build_name,
                        architect,
                        system_name=sys_name,
                        body_name=payload.get("bodyName", ""),
                        body_num=payload.get("bodyNum"),
                        commodities=_state["commodities"].get(payload["marketId"]),
                    )
                    if result:
                        # Raven created the build — now register it on the board.
                        _set_status("created in Raven — registering on board…")
                        payload["create"] = False
                        _post(payload, market_id, False)
                    else:
                        # _raven_create already updated status + last_error.json
                        _state["pending"][market_id] = time.time()  # re-arm grace
                    return
                # No build yet, not creating — keep waiting.
                _report_waiting(market_id)
                return
            # Any other non-2xx is a real failure: persist the full body so we're never blind.
            _write_last_error(he.code, raw, payload)
            reason = detail.get("reason") if isinstance(detail, dict) else None
            err = detail.get("error") if isinstance(detail, dict) else None
            if he.code == 401:
                _set_status("auth error (bad key)")
            elif reason == "raven_auth":
                _set_status("auto-create needs Raven login — create it in SrvSurvey")
            elif reason:
                # deadline / handler_error / raven_timeout / raven_400 / conflict / ...
                _set_status("auto-create failed (" + str(reason) + ") — logged, will retry")
                if was_create:
                    _state["pending"][market_id] = time.time()  # re-arm grace; don't hammer Raven
            elif err:
                _set_status(str(err) + " " + str(he.code) + " — logged")
                if was_create:
                    _state["pending"][market_id] = time.time()
            else:
                # Bare / non-JSON gateway error (e.g. a raw Cloudflare 502). We captured the body.
                _set_status("server error " + str(he.code) + " (no reason — see last_error.json)")
                if was_create:
                    _state["pending"][market_id] = time.time()
            return
        if body.get("ok"):
            _state["seen"].add(market_id)
            _state["pending"].pop(market_id, None)
            _save_seen()
            if body.get("created"):
                who = body.get("architect") or "?"
                tag = {"claim": " (claimed ✓)", "raven-siblings": " (from Raven)",
                       "fallback": " (fallback — fix later)"}.get(body.get("architectSource") or "", "")
                _set_status("created " + (body.get("name") or body.get("id", "build")) + " · architect " + who + tag)
            elif body.get("added"):
                _set_status("registered " + (body.get("name") or body.get("id", "build")))
            else:
                _set_status("already listed")
        else:
            _write_last_error(200, raw, payload)
            _set_status("skip (" + str(body.get("error", "?")) + ") — logged")
    except Exception as e:
        _write_last_error(0, "client exception: " + str(e), payload)
        _set_status("post failed (offline?) — logged")


def _report_waiting(market_id):
    if _autocreate():
        first = _state["pending"].get(market_id)
        if first is None:
            _set_status("waiting — no build in Raven yet")
            return
        remaining = int(_grace_seconds() - (time.time() - first))
        if remaining > 0:
            m, s = divmod(remaining, 60)
            _set_status("waiting — auto-create in %dm%02ds" % (m, s))
        else:
            _set_status("waiting — arming auto-create…")
    else:
        _set_status("waiting — create the build in Raven first")


def journal_entry(cmdr, is_beta, system, station, entry, state):
    ev = entry.get("event")

    # Track location context from any event that carries it.
    if entry.get("SystemAddress"):
        _state["sa"] = entry["SystemAddress"]
    elif state and state.get("SystemAddress"):
        _state["sa"] = state.get("SystemAddress")
    if system:
        _state["system"] = system
    if entry.get("BodyName"):
        _state["body"] = entry.get("BodyName")
    elif entry.get("Body") and isinstance(entry.get("Body"), str):
        _state["body"] = entry.get("Body")
    if entry.get("BodyID") is not None:
        _state["bodynum"] = entry.get("BodyID")

    # Ship + cargo hold: Loadout carries ship + max cargo, Cargo the current tonnage,
    # LoadGame the ship at login. Report the merged picture to /ingest/loadout (debounced).
    if ev in ("Loadout", "LoadGame", "Cargo"):
        if ev in ("Loadout", "LoadGame"):
            sh = entry.get("Ship")
            if sh:
                _LO["ship"] = str(sh)
            sn = entry.get("ShipName")
            if sn is not None:
                _LO["shipName"] = str(sn)
        if ev == "Loadout":
            cap = entry.get("CargoCapacity")
            if cap is not None:
                try:
                    _LO["cargoCap"] = int(cap)
                except Exception:
                    pass
        if ev == "Cargo":
            cnt = entry.get("Count")
            if cnt is not None:
                try:
                    _LO["cargoUsed"] = int(cnt)
                except Exception:
                    pass
        _maybe_send_loadout(cmdr, _iso_ms(entry.get("timestamp")), force=(ev == "Loadout"))
        return

    # Claims ledger: ColonisationSystemClaim fires when YOU pay for a system claim
    # (at the colonisation contact) — you are the architect; report it. Release undoes it.
    if ev in ("ColonisationSystemClaim", "ColonisationSystemClaimRelease"):
        sa = entry.get("SystemAddress")
        if sa:
            # Cache locally for architect detection during auto-create.
            if ev == "ColonisationSystemClaim":
                _state["claims"][sa] = cmdr or "unknown"
            else:
                _state["claims"].pop(sa, None)
            action = "claim" if ev == "ColonisationSystemClaim" else "release"
            sys_name = entry.get("StarSystem") or system or ""
            payload = {
                "key": INGEST_KEY,
                "systemAddress": sa,
                "systemName": sys_name,
                "cmdr": cmdr or "unknown",
                "action": action,
                "ts": _iso_ms(entry.get("timestamp")),
                "via": "live",
            }
            label = ("architect claim logged: " if action == "claim" else "claim released: ") + (sys_name or str(sa))
            threading.Thread(target=_send_claim, args=(payload, label), daemon=True).start()
        return

    # Fleet-carrier ownership: CarrierStats fires in the owner's own journal when they open
    # carrier management. For a carrier CarrierID == MarketID, which is what Raven's fc-link
    # wants -- report it so the commander deck can offer "link my carrier to a build".
    if ev == "CarrierStats":
        mid = entry.get("CarrierID")
        if mid:
            payload = {
                "key": INGEST_KEY,
                "marketId": mid,
                "callsign": entry.get("Callsign") or "",
                "name": entry.get("Name") or "",
                "cmdr": cmdr or "unknown",
                "ts": _iso_ms(entry.get("timestamp")),
                "via": "live",
            }
            threading.Thread(target=_send_carrier,
                             args=(payload, "carrier logged: " + (entry.get("Name") or entry.get("Callsign") or str(mid))),
                             daemon=True).start()
        return

    if ev != "ColonisationConstructionDepot":
        return

    market_id = entry.get("MarketID")
    sa = _state["sa"] or (state.get("SystemAddress") if state else None)
    if not market_id or not sa:
        return
    if market_id in _state["seen"]:
        return  # already registered this depot

    # Capture commodity requirements from the journal event for Raven create.
    resources = entry.get("ResourcesRequired") or []
    if resources:
        comms = {}
        for r in resources:
            raw = (r.get("Name") or "").lower()
            # Strip ED's "$..._name;" wrapper → bare commodity key
            if raw.startswith("$") and raw.endswith("_name;"):
                raw = raw[1:-6]
            amt = r.get("RequiredAmount", 0)
            if raw and amt:
                comms[raw] = amt
        if comms:
            _state["commodities"][market_id] = comms

    now = time.time()
    _state["pending"].setdefault(market_id, now)

    do_create = False
    if _autocreate() and (now - _state["pending"][market_id]) >= _grace_seconds():
        do_create = True

    payload = {
        "key": INGEST_KEY,
        "marketId": market_id,
        "systemAddress": sa,
        "cmdr": cmdr or "unknown",
        "create": False,  # never ask the CF function to create — plugin does it directly
        "architect": _architect(),
        "systemName": _state.get("system") or system or "",
        "bodyName": _state.get("body") or "",
        "bodyNum": _state.get("bodynum"),
    }
    threading.Thread(target=_post, args=(payload, market_id, do_create), daemon=True).start()
